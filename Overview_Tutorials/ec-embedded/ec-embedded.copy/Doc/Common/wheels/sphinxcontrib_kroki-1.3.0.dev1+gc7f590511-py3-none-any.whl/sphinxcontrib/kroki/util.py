from sphinx.util import logging

logger = logging.getLogger(__name__)
